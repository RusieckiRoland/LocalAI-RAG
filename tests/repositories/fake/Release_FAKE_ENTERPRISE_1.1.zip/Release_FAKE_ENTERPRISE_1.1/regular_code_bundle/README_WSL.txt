FakeEnterprise test bundle
- English-only content
- Mixed C# and SQL dependencies
- Security metadata distribution: 70% none, 15% ACL only, 10% classification only, 5% both
